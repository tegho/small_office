#!/bin/bash

rndc sync -clean
